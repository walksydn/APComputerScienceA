/**
 * ---------------------------------------------------------------------------
 * S-h-e-n-e-n-d-e-h-o-w-a--H-i-g-h--S-c-h-o-o-l--T-e-c-h-n-o-l-o-g-y--D-e-p-t
 * ---------------------------------------------------------------------------
 * FILE: StringPracticeApp.java
 *
 * DATE:  2010
 *
 * PURPOSE: Launches deliciousness that is the StringPracticeFrame. Love it!!
 *
 * @author mr Hanley
 * @version 3.14159
 * ---------------------------------------------------------------------------
 *
 * h-a-n-l-e-y.c-o-.-n-r------t-e-a-m-2-0-.-c-o-m-----------------------------
 */
public class StringPracticeApp {
    public static void main(String[] args) {
        StringPractFrame f = new StringPractFrame();
        f.setBounds(100,50,1220,770);
        f.setVisible(true);
        
    }
}
